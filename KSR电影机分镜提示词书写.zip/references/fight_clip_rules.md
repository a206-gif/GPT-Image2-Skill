# 打斗CLIP专用规则

## 核心原则

1. **打斗不是回合制** — 每个动作的end state直接是下一个动作的start state，零停顿零喘息。攻击和反击交织，不A完才B
2. **巨物但行动极速** — 不要因为Boss/巨物体型大就让它慢，挥拍/重击/乱抓都是极速
3. **能量汇聚不停顿** — 要么只给1秒特写，要么在角色移动中直接汇聚好
4. **拳拳到肉有物理规律** — 每次击打双方有物理反馈
5. **整段快到令人窒息**

## 多组镜头+急速运镜

1. 不能只6个Shot，需要更多快剪镜头
2. 运镜必须晃动急速
3. 可以加急速环绕（Orbit）
4. 每镜运镜不同，每拍改变≥2项

## 压迫感镜头技巧

1. 极低角度仰拍（膝盖以下/积水高度）使巨物从上方俯压
2. 前景遮挡（积水碎石水雾）制造"潜伏观察"窒息感
3. 巨物占画面70%+
4. 积水倒影扭曲拉长
5. 透视关系极端拉大近大远小
6. 地平线压到画面底部

## 荷兰角制造失衡感

- 画面倾斜15度，每次格挡倾斜加剧
- 回正=稳住了=要反击了
- 用构图倾斜传递角色处境

## 短暂震颤定格增强打击感

- 每次impact镜头猛震前推+短暂震颤定格
- 不是一直晃，是打中那一下震一下定一下

## 物理反馈递进

每次击打必须有递进的物理反馈链：
- 第1击：表面凹陷/碎裂
- 第2击：躯干扭曲/后仰
- 第3击：被轰飞/倒地

## 能量文字锚定模板

能量汇聚在角色移动中自然完成，不停顿。需明确颜色+来源+覆盖范围+爆发效果。

## 英雄镜头设计原则

- 侧面低角度仰拍给力量感
- 蓄力→爆发动作链
- 甩完保持伸展姿势定格一拍
- 飞刀脱手到扎入不超过1秒（如适用）

## 打斗CLIP负面限制选题库（从中选取3-8项与本次打斗最相关的，不要全贴）

```
no slow Boss action, no sluggish giant movement, no turn-based combat pacing, no pause between attacks, no charging pause for energy buildup, no weightless block, no weightless punch, no missing impact reaction, no weapon morph, no camera shake hiding action peak, no constant loud music covering combat sounds, no impact without debris or water reaction, no energy blast without shockwave
```
