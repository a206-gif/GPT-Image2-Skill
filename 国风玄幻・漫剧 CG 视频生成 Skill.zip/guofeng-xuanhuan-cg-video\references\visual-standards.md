# 固定视觉标准（所有输出自动套用）

## 视觉维度标准
| 维度 | 标准 |
| --- | --- |
| 风格 | 国风动漫3DCG电影感，写实建模 |
| 渲染 | 电影级物理渲染（PBR材质），次表面散射（SSS）皮肤质感 |
| 色彩 | 固定电影级青橙色调（Teal & Orange） |
| 光影 | 丁达尔效应（体积光），雾气，水面/湿地倒影反射 |
| 画质 | 8K超高清，细节丰富，纹理清晰 |
| 镜头 | 浅景深，呼吸感运镜，宁静宿命感氛围 |

## 提示词规范
### 固定正向质量标签（附加到所有画面提示词末尾）
> masterpiece, best quality, 8k, highly detailed, cinematic lighting, volumetric fog, ethereal atmosphere

### 固定反向词（附加到所有负面提示词）
> cartoon style, cel-shading, flat coloring, oil painting, western face, modern elements, low quality, blurry, distortion, deformed, text, watermark, weapons pointing at camera, gore, horror, political symbols, nudity

### 分镜提示词结构模板
`[景别与镜头运动] + [场景与环境] + [角色外貌与动作] + [时间/天气/光线] + [情绪氛围]`，末尾追加固定正向质量标签；负面提示词使用固定反向词。

### 示例分镜提示词
- 景别：中景，缓慢推镜
- 场景：雨后黄昏山谷，青石板桥，桃树，远山镜湖，丁达尔光
- 角色：女主，20岁，浅青色纱衣，白色长裙，三鬟髻，蓝色绢花流苏发簪，撑伞走过石桥，花瓣落于发间，低头一笑
- 光线：黄昏体积光，水面倒影
- 氛围：宁静宿命感

## 视频生成参数建议
| 形态 | 比例 | 单段时长 | 总时长 | 方式 |
| --- | --- | --- | --- | --- |
| A. 竖屏短剧 | 9:16 | 5–10秒 | 15–60秒 | 分镜图作首帧/参考图逐段生成，按剧本顺序拼接 |
| B. 横屏叙事短片 | 16:9 | 5–15秒 | 60–180秒 | 同上 |

## 生成参数记录
每次生成须记录：模型版本、种子、分辨率/比例、单段时长、提示词版本，随产出物清单一并交付。
